import { UserCardList } from "./UserCardList";

const App = () => {
  return (
     <UserCardList/>
  );
};

export default App;
