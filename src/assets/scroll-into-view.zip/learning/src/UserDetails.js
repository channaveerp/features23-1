export const UserDetails = ({ userId }) => {

    return <div>
        <p>
            Render user detail information
        </p><p>
            Render user detail information
        </p><p>
            Render user detail information
        </p><p>
            Render user detail information
        </p><p>
            Render user detail information
        </p><p>
            Render user detail information
        </p>

    </div>;
};
