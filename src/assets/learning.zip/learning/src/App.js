
import { UserCardList } from './UserCardList';

function App() {
  return (
    <div className="App">
      <UserCardList/>
    </div>
  );
}

export default App;
