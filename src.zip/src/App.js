import './App.css';
import Edit from './component/EditProfile/Edit';

// import ElasticSearch from './component/elasticsearch';
// import Contactus from './component/form';
// import { Search } from './component/search_network_request';
// import { Tabs } from './component/tabs';
// import Search from './component/search_funct';

function App() {
  return (
    <div className='App'>
      {/* <h1>lets start</h1> */}
      {/* <Contactus /> */}
      {/* <Tabs /> */}
      {/* <Search /> */}
      {/* <Search /> */}
      {/* <ElasticSearch/> */}
    <Edit/>
    </div>
  );
}

export default App;
