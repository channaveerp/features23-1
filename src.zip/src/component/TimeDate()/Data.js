const data = [
    {
        name:"channa",
        place:"India",
        date:""
    }
]